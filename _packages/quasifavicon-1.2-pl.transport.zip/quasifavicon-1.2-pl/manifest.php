<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'a700578a8686899496685506dd02da31',
      'native_key' => 'quasifavicon',
      'filename' => 'modNamespace/0381e1651497aac340bebbcd0102bc02.vehicle',
      'namespace' => 'quasifavicon',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '6081ff38cf748caf3ead744c9da82ad6',
      'native_key' => 1,
      'filename' => 'modCategory/618414b45c7aeae11581193fc46f554c.vehicle',
      'namespace' => 'quasifavicon',
    ),
  ),
);