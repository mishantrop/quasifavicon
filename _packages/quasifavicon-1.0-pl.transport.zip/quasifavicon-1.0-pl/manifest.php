<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '1c52e2884a7c02a257186a7748a38cbf',
      'native_key' => 'quasifavicon',
      'filename' => 'modNamespace/de4ece9635f4e53feda1073f22d2e668.vehicle',
      'namespace' => 'quasifavicon',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '4b651e396cb7c74026217891837df38d',
      'native_key' => 1,
      'filename' => 'modCategory/d7b53cc4ba173d7566d2b20cab3c892a.vehicle',
      'namespace' => 'quasifavicon',
    ),
  ),
);