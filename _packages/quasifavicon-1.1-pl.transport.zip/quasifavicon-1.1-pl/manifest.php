<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '824733d1c63086e88f410cdf885a48cb',
      'native_key' => 'quasifavicon',
      'filename' => 'modNamespace/6a8d456bb286c704f5ecc111cf339cc2.vehicle',
      'namespace' => 'quasifavicon',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '8eb5540ec1d5b83ab7173b1e23350d87',
      'native_key' => 1,
      'filename' => 'modCategory/70617d72eecf1cbbcc3972ef4a9b9af7.vehicle',
      'namespace' => 'quasifavicon',
    ),
  ),
);